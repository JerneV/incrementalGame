package main;

import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.DropMode;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;

import player.*;

public class Main extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	Player player = new Player();
	String inputText = "";
	Inventory inventory = new Inventory();

	public static void main(String[] args) {
		new Main().setVisible(true); //Makes JFrame visible
		doIntro();
	}

	private Main() {
		super("Jerne's RRPG"); //Setting the title
		setSize(900, 700); //Still need to find the right size
		setResizable(false); //Mag niet
		setDefaultCloseOperation(EXIT_ON_CLOSE); //Close the program after closing the window
		setLayout(new GridLayout(3, 4, 5, 10)); //To test we create a 3x4 grid
		setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT); //Left to right orientation, because why not?
	
		JTextArea output = new JTextArea(); //Place where text will be displayed
		output.setEditable(false); //This should not be editable
		add(output); //Adding
				
		JTextArea input = new JTextArea(); //Place where we'll type stuff
		input.setToolTipText("Type here!"); //just a tooltip
		input.addKeyListener(new KeyListener(){

			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode() == KeyEvent.VK_ENTER){
					inputText(input.getText());
					System.out.println("Enter pressed");
				}
				
			}
			public void keyReleased(KeyEvent e) {}
			public void keyTyped(KeyEvent e) {}

		});
		add(input); //Adding
	
		JButton enterButton = new JButton("Enter");
		enterButton.addActionListener(this); //Adding actionlistener to the button
		enterButton.setActionCommand("enterButton"); //We manually set the actionCommand so we know what it is in the future
		add(enterButton); //Adding the button
	
	
	}


	@Override
	public void actionPerformed(ActionEvent arg0) { //Listener
		String actionName = arg0.getActionCommand(); //Getting the action command so we know which button was pressed
		if(actionName == "enterButton"){
			System.out.println("Button clicked");
			inputText(null);
		}else if(actionName == ""){
			
		}
		
	}
	
	private void inputText(String s) { //Method to display text on output frame
		
		
	}

	private static void doIntro() { //The part where the story gets explained and the player gets his name comes here.
		
		
		
	}



	
}


